<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=good',
    'username' => 'root',
    'password' => 'wechat',
    'charset' => 'utf8',
];
