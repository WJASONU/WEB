<?php
return[
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => [
            	"/" => "/default/index"
            ],
        ];