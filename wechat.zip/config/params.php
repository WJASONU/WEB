<?php

return [
    'weixin' => [
		'appid' => 'wx2fa793767bec871c',
		'sk' => '05524873a9bdf8cce8e1f3222bec6e24',
		'token' => 'wexin',
		'aeskey' => '',
		'pay' => [
			'key' => '根据实际情况填写',
			'mch_id' => '根据实际情况填写',
			'notify_url' => [
				'm' => '/pay/callback'
			]
		]
	]
];

