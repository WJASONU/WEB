<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>微信商城</title>
    <link href="/css/www/app.css" rel="stylesheet"></head>
<body>
<div class="navbar navbar-inverse" role="navigation">
    <div class="container">
        <div class="navbar-collapse collapse pull-left">
            <ul class="nav navbar-nav ">
                <li><a href="http://wzx.wechat.test/">首页</a></li>
                <li><a href="http://wzx.wechat.test/web/user/login">管理后台</a></li>
            </ul>
        </div>
    </div>
</div>
<!-- begin -->
<?=$content;?>



</body></html>
