<div class="jumbotron body-content">
    <div class="jumbotron text-center">
        <img src="/images/common/qrcode.png">
        <h3>扫码关注公众号</h3>
    </div>
</div>
