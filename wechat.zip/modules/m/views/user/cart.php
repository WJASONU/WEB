<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<!-- Set render engine for 360 browser -->
	<meta name="renderer" content="webkit">
	<title>微信商城</title>
	<link href="/font-awesome/css/font-awesome.css" rel="stylesheet">
<link href="/css/m/css_style.css" rel="stylesheet">
<link href="/css/m/app.css?ver=20170401" rel="stylesheet"></head>
<body>
<div style="min-height: 500px;">
	<div class="order_pro_box">
    	<ul class="order_pro_list">
        		<li data-price="78.20">
			<a href="/m/product/info?id=4" class="pic" >
                <img src="/uploads/book/20170316/32762d0f7036d9a8c160dfa513d2797c5d4.jpg" style="height: 100px;width: 100px;"/>
            </a>
			<h2><a href="/m/product/info?id=4">计算机原理</a></h2>
			<div class="order_c_op">
				<b>¥78.20</b>
				<span class="delC_icon" data="1" data-book_id="4"></span>
				<div class="quantity-form">
					<a class="icon_lower" data-book_id="4" ></a>
					<input type="text" name="quantity" class="input_quantity" value="1" readonly="readonly" max="129" />
					<a class="icon_plus" data-book_id="4"></a>
				</div>
			</div>
		</li>
        	</ul>
    </div>
<div class="cart_fixed">
	<a href="/m/product/order?sc=cart" class="billing_btn">结算</a>
	<b>合计：<strong>¥</strong><font id="price">0.00</font></b>
</div></div>
<div class="copyright clearfix">
	        <p class="name">欢迎您，用户</p>
</div>
<div class="footer_fixed clearfix">
	<span><a href="/m/" class="default"><i class="home_icon"></i><b>首页</b></a></span>
	<span><a href="/m/product/index" class="product"><i class="store_icon"></i><b>商品</b></a></span>
	<span><a href="/m/user/index" class="user"><i class="member_icon"></i><b>我的</b></a></span>
</div>

</body>
</html>